
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LFM
 */
public class loginpage extends javax.swing.JFrame implements LoginInterface {

    /**
     * Creates new form login page
     */
    
    // two different head will represent 2 different linkedlist.
    Node1 head=null;
    Node1 head2=null;
    
    String username;
    String password;
    
    String currentTime;
    String currentDate;
    
    
    public loginpage() {
        initComponents();
    }
    
    
    
      public boolean login(){// process of login-- verification
        // it is using head (out of 2 linked list's heads) 
       this.username=username1Field.getText();
            this.password=password1Field.getText();
            boolean login=false;
            
            System.out.print(username1Field.getText() +" "+password1Field.getText());
       
       try{
           
           FileReader fr=new FileReader("RegisterRecord.txt"); // reading data from this particular txt file
           BufferedReader br=new BufferedReader(fr);
           String line,user,pass;
           
           Node1 temp1;
         
           int i=0;
           while((line=br.readLine()) !=null){ //  reading each line from file
                user=line.split("\t")[0];
                pass=line.split("\t")[1];
                Node1 new_node=new Node1(user,pass);
                
                // as we are storing data in linked 
                 if(head==null){
                    head=new_node;
                }
                else{
                 temp1=head;
                     while(temp1.next!=null)
                     {
                        temp1=temp1.next;
                     }
                     temp1.next=new_node;
                }
                 
                i++;
               }
           
            temp1=head;
                while(temp1!=null)
                {
                    if(username.equals(temp1.username) && (temp1.password.equals(password)))
                    {
                   login=true;
                   break;
                    }
                else
                   temp1=temp1.next;
                }
                
                //line=br.readLine();   
            fr.close();
       }
       catch(Exception e){
           System.out.println("cannot open file");
       }
       
       return login;
    }
      
      public void updateLogin(String username){
          try{
              
              FileWriter fw=new FileWriter(username+"\\login.txt",true);
              SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy"+"\t\t\t"+"HH:mm:ss");
              Date date=new Date();
              System.out.println(f.format(date));
              currentDate=f.format(date);
              fw.write(currentDate+"\r\n");
              fw.close();
              
          }
          catch(Exception e){
              System.out.println(username+" file cannnot be open");
          }
          
      }
    
    public void  updateLoginRecord(String username)
    {
        insertion(username);
        try{
            FileWriter fw=new FileWriter("LoginRecord.txt");
            
            Node1 temp=head2;
             while(temp!=null)
             {
                  fw.write(temp.username+"\r\n");
                  temp=temp.next;
             }
            
            fw.close();
            
        }
        catch(Exception e)
        {
            System.out.println("file cannot be open");
        }
    }
    
    
    public void insertion(String username){
        
       insertionFromFile();
        
        Node1 new_node = new Node1(username);
        if (head2==null)
            head2=new_node;
        else{
            new_node.next=head2;
            head2=new_node;
            
        }
    }
    
    
    public void insertionFromFile(){
        String username1;
        try{
            FileReader fr=new FileReader("LoginRecord.txt");
           BufferedReader br=new BufferedReader(fr);
           
           int i=0;
            String line;
           while((line=br.readLine()) !=null)
           {
                username1=line;               
                
                Node1 new_node=new Node1(username1);
                
                if(head2==null){
                    head2=new_node;
                }
                else{
                    Node1 temp=head2;
                     while(temp.next!=null){
                         temp=temp.next;
                     }
                     temp.next=new_node;
                }
               
                i++;
           }
   
        }
        catch(Exception e){
            System.out.println("cannot open file");
        }
     
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btr = new javax.swing.JLabel();
        description = new javax.swing.JLabel();
        username1 = new javax.swing.JLabel();
        password1 = new javax.swing.JLabel();
        username1Field = new javax.swing.JTextField();
        LoginButton = new javax.swing.JButton();
        RegisterButton1 = new javax.swing.JButton();
        password1Field = new javax.swing.JPasswordField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btr.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        btr.setText("BUS TICKET RESERVATION");

        description.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        description.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        description.setText("It is an online Bus Reservation Portal where you can book, cancel your ride for anyone from anywhere");

        username1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        username1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        username1.setText("Username");

        password1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        password1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        password1.setText("Password");

        username1Field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        username1Field.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        username1Field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                username1FieldActionPerformed(evt);
            }
        });

        LoginButton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        LoginButton.setText("LOGIN");
        LoginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginButtonActionPerformed(evt);
            }
        });

        RegisterButton1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        RegisterButton1.setText("REGISTER");
        RegisterButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterButton1ActionPerformed(evt);
            }
        });

        password1Field.setText("jPasswordField1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(141, 141, 141)
                        .addComponent(btr, javax.swing.GroupLayout.PREFERRED_SIZE, 535, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(description))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(LoginButton)
                            .addGap(84, 84, 84)
                            .addComponent(RegisterButton1)
                            .addGap(73, 73, 73))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGap(440, 440, 440)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(password1)
                                .addComponent(username1))
                            .addGap(34, 34, 34)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(username1Field, javax.swing.GroupLayout.DEFAULT_SIZE, 206, Short.MAX_VALUE)
                                .addComponent(password1Field)))))
                .addContainerGap(91, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(38, 38, 38)
                .addComponent(btr, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(description)
                .addGap(69, 69, 69)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(username1)
                    .addComponent(username1Field, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(password1)
                    .addComponent(password1Field, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(LoginButton)
                    .addComponent(RegisterButton1))
                .addContainerGap(312, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void username1FieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_username1FieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_username1FieldActionPerformed

    private void LoginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginButtonActionPerformed
        // TODO add your handling code here:
      boolean found=this.login();
      if(found){
        updateLogin(username);
        updateLoginRecord(username);
        
//       Reservation f2=new Reservation();
//       f2.setVisible(true);

menu m=new menu();
m.setVisible(true);
       JOptionPane.showMessageDialog(null, "Successfully login");
       this.dispose();
      }
      else{
          JOptionPane.showMessageDialog(null, "Un-Successfully login");
      }
    }//GEN-LAST:event_LoginButtonActionPerformed

    private void RegisterButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterButton1ActionPerformed
        // TODO add your handling code here:
        RegistrationPage r = new RegistrationPage();
        r.setVisible(true);
    }//GEN-LAST:event_RegisterButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(loginpage.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new loginpage().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton LoginButton;
    private javax.swing.JButton RegisterButton1;
    private javax.swing.JLabel btr;
    private javax.swing.JLabel description;
    private javax.swing.JLabel password1;
    private javax.swing.JPasswordField password1Field;
    private javax.swing.JLabel username1;
    private javax.swing.JTextField username1Field;
    // End of variables declaration//GEN-END:variables
}
// Linkedlist implementation.
class Node1{
    String username;
    String password;
    Node1 next;
    
    Node1(String username, String password){
        this.username=username;
        this.password=password;
        next=null;
    }
    Node1(String username){
        this.username=username;
        next=null;
    }
}