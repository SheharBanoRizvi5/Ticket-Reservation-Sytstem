
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author LFM
 */
public class Reservation extends javax.swing.JFrame {

    int fare = 500;
    int tax = 15;
   // int miles = 0;
    int Tfare = 0;
    int Dtax = 0;
    int SubTotal = 0;
    String passengernum;
    String to = null,from, depTime, traveltype, traveldate, date,tickettype;
     StackLinkedlist sl=new StackLinkedlist();
    public Reservation() {
        initComponents();
    }   
    
   
    public String retrieveCurrentUser(){
        String currentuser=null;
        try
        {
            FileReader fr=new FileReader("LoginRecord.txt");
             BufferedReader br=new BufferedReader(fr);
             currentuser=br.readLine();
             System.out.println("current user="+currentuser);
            fr.close();
            
        }
        catch(Exception e)
        {
            System.out.println("cannot open file");
        }
        
        return currentuser;
    }
    
    public void updateReserve(String from,String to,String traveldate,String depTime,String passengernum,String traveltype){
        
        String usernamefile=retrieveCurrentUser();
        String currentDate;
         try{
             FileWriter fw=new FileWriter(usernamefile+"\\reservation.txt",true);
             SimpleDateFormat f=new SimpleDateFormat("dd/MM/yyyy"+"\t"+"HH:mm:ss");
              Date date=new Date();
              System.out.println(f.format(date));
              currentDate=f.format(date);
              
              fw.write(currentDate+"\t"+from+"\t"+to+"\t"+traveldate+"\t"+depTime+"\t"+passengernum+"\t"+traveltype+"\r\n");
              
             
              fw.close();
          }
          catch(Exception e){
              System.out.println(" file cannnot be open");
          }
    }
    
    
 
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Review = new javax.swing.JButton();
        Submit = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        total1 = new javax.swing.JLabel();
        tax1 = new javax.swing.JLabel();
        sub_total1 = new javax.swing.JLabel();
        total1Field = new javax.swing.JTextField();
        tax1field = new javax.swing.JTextField();
        SubTotalField1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        doj1 = new javax.swing.JLabel();
        dep1 = new javax.swing.JLabel();
        dest = new javax.swing.JLabel();
        ticket_type1 = new javax.swing.JLabel();
        class1 = new javax.swing.JLabel();
        passengers1 = new javax.swing.JLabel();
        dest1field = new javax.swing.JComboBox<>();
        dep1field = new javax.swing.JComboBox<>();
        SingleButton = new javax.swing.JRadioButton();
        ReturnButton = new javax.swing.JRadioButton();
        FirstClassButton = new javax.swing.JRadioButton();
        EconomyButton = new javax.swing.JRadioButton();
        passengers1Field = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        from1f = new javax.swing.JComboBox<>();
        doj1Field = new com.toedter.calendar.JDateChooser();
        jPanel2 = new javax.swing.JPanel();
        passengers2Field = new javax.swing.JTextField();
        passengers2 = new javax.swing.JLabel();
        amountpaid2field = new javax.swing.JTextField();
        confirmbutton = new javax.swing.JButton();
        exitbutton = new javax.swing.JButton();
        from2field = new javax.swing.JTextField();
        to2field = new javax.swing.JTextField();
        doj2Field = new javax.swing.JTextField();
        doj2 = new javax.swing.JLabel();
        dep2field = new javax.swing.JTextField();
        T_type1Field = new javax.swing.JTextField();
        class2Field = new javax.swing.JTextField();
        amountpaid2 = new javax.swing.JLabel();
        class2 = new javax.swing.JLabel();
        T_type1 = new javax.swing.JLabel();
        dep2 = new javax.swing.JLabel();
        To2 = new javax.swing.JLabel();
        From2 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Review.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Review.setText("REVIEW");
        Review.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReviewActionPerformed(evt);
            }
        });

        Submit.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        Submit.setText("SUBMIT");
        Submit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SubmitActionPerformed(evt);
            }
        });

        total1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        total1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        total1.setText("TOTAL");

        tax1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tax1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        tax1.setText("TAX");

        sub_total1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        sub_total1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        sub_total1.setText("SUB TOTAL");

        total1Field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        total1Field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                total1FieldActionPerformed(evt);
            }
        });

        tax1field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        SubTotalField1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(total1)
                    .addComponent(tax1)
                    .addComponent(sub_total1))
                .addGap(88, 88, 88)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(tax1field, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                    .addComponent(total1Field)
                    .addComponent(SubTotalField1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(total1)
                    .addComponent(total1Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tax1)
                    .addComponent(tax1field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sub_total1)
                    .addComponent(SubTotalField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(32, Short.MAX_VALUE))
        );

        jLabel1.setBackground(new java.awt.Color(0, 51, 51));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("BUS TICKETING SYSTEM");

        doj1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        doj1.setText("DATE OF JOURNEY");

        dep1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dep1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dep1.setText("DEPARTURE");

        dest.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dest.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dest.setText("DESTINATION");

        ticket_type1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        ticket_type1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        ticket_type1.setText("TICKET TYPE");

        class1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        class1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        class1.setText("CLASS");

        passengers1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        passengers1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        passengers1.setText("NUMBER OF PASSENGERS");

        dest1field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dest1field.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Lahore", "Peshawar", "Karachi", "Kashmir", "Multan" }));
        dest1field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dest1fieldActionPerformed(evt);
            }
        });

        dep1field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dep1field.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "8:30am", "10:30am", "8:30pm" }));
        dep1field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dep1fieldActionPerformed(evt);
            }
        });

        SingleButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        SingleButton.setText("SINGLE");
        SingleButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SingleButtonActionPerformed(evt);
            }
        });

        ReturnButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        ReturnButton.setText("RETURN");
        ReturnButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReturnButtonActionPerformed(evt);
            }
        });

        FirstClassButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        FirstClassButton.setText("FIRST CLASS");
        FirstClassButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                FirstClassButtonActionPerformed(evt);
            }
        });

        EconomyButton.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        EconomyButton.setText("ECONOMY");

        passengers1Field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("FROM");

        from1f.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        from1f.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Islamabad", "Lahore", "Karachi" }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(doj1)
                    .addComponent(dep1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ticket_type1)
                    .addComponent(class1)
                    .addComponent(passengers1)
                    .addComponent(dest, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(128, 128, 128)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(passengers1Field)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(SingleButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(ReturnButton, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(FirstClassButton)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(EconomyButton))
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(from1f, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(dest1field, javax.swing.GroupLayout.Alignment.LEADING, 0, 181, Short.MAX_VALUE)
                                .addComponent(dep1field, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(doj1Field, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(from1f, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(dest, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(dest1field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(doj1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(doj1Field, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dep1)
                            .addComponent(dep1field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ticket_type1)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(SingleButton)
                                .addComponent(ReturnButton)))
                        .addGap(18, 18, 18)
                        .addComponent(class1))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(FirstClassButton)
                        .addComponent(EconomyButton)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(passengers1)
                    .addComponent(passengers1Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(23, Short.MAX_VALUE))
        );

        passengers2Field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        passengers2Field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                passengers2FieldActionPerformed(evt);
            }
        });

        passengers2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        passengers2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        passengers2.setText("NUMBER OF PASSENGERS");

        amountpaid2field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        confirmbutton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        confirmbutton.setText("CONFRIM");
        confirmbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                confirmbuttonActionPerformed(evt);
            }
        });

        exitbutton.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        exitbutton.setText("EXIT");
        exitbutton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitbuttonActionPerformed(evt);
            }
        });

        from2field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        from2field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                from2fieldActionPerformed(evt);
            }
        });

        to2field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        to2field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                to2fieldActionPerformed(evt);
            }
        });

        doj2Field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        doj2Field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doj2FieldActionPerformed(evt);
            }
        });

        doj2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        doj2.setText("DATE OF JOURNEY");

        dep2field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        T_type1Field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        class2Field.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        amountpaid2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        amountpaid2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        amountpaid2.setText("AMOUNT PAID");

        class2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        class2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        class2.setText("CLASS");

        T_type1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        T_type1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        T_type1.setText("TICKET TYPE");

        dep2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        dep2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        dep2.setText("DEPARTURE");

        To2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        To2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        To2.setText("TO");

        From2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        From2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        From2.setText("FROM");

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("REVIEW PORTAL");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(194, 194, 194)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 248, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(49, 49, 49)
                                        .addComponent(From2))
                                    .addGroup(jPanel2Layout.createSequentialGroup()
                                        .addGap(59, 59, 59)
                                        .addComponent(To2))
                                    .addComponent(doj2))
                                .addGap(33, 33, 33)
                                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(doj2Field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(to2field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(from2field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dep2field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(T_type1Field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(class2Field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(passengers2Field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(amountpaid2field, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(236, 236, 236)
                        .addComponent(class2))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(passengers2)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(dep2)
                                .addComponent(T_type1))))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(185, 185, 185)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(amountpaid2)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(confirmbutton)
                                .addGap(105, 105, 105)
                                .addComponent(exitbutton)))))
                .addContainerGap(136, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addComponent(jLabel2)
                .addGap(39, 39, 39)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(from2field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(From2))
                .addGap(36, 36, 36)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(To2)
                    .addComponent(to2field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(doj2)
                    .addComponent(doj2Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(dep2, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dep2field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(T_type1)
                            .addComponent(T_type1Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(37, 37, 37)
                        .addComponent(class2))
                    .addComponent(class2Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(passengers2)
                    .addComponent(passengers2Field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(61, 61, 61)
                        .addComponent(amountpaid2)
                        .addGap(31, 31, 31))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(amountpaid2field, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(confirmbutton)
                    .addComponent(exitbutton))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(265, 265, 265)
                        .addComponent(Submit))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(259, 259, 259)
                        .addComponent(Review))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(232, 232, 232)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 313, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Submit)
                .addGap(33, 33, 33)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Review)
                .addContainerGap(117, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ReviewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReviewActionPerformed

    if(from1f.getSelectedItem().equals("Islamabad")){
           this.from="Islamabad";
          // from2field.setText("Islamabad");
           sl.push(from);
           
           }
            else if(from1f.getSelectedItem().equals("Lahore")){
               this.from="Lahore";
              // from2field.setText("Lahore");
               sl.push(from);
           }
           else if(from1f.getSelectedItem().equals("Karachi")){
                this.from="Karachi";
              // from2field.setText("Karachi");
               sl.push(from);
           }
           
           
         if(dest1field.getSelectedItem().equals("Lahore")){
            this.to="Lahore";
            // to2field.setText("Lahore");
             sl.push(to);
         }
          else if(dest1field.getSelectedItem().equals("Kashmir")){
            this.to="Kashmir";
            // to2field.setText("Kashmir");
              sl.push(to);
         }
         else if(dest1field.getSelectedItem().equals("Karachi")){
             this.to="Karachi";
             //to2field.setText("Karachi");
              sl.push(to);
         }         
         else if(dest1field.getSelectedItem().equals("Multan")){
             this.to="Multan"; 
             sl.push(to);
             //to2field.setText("Multan");
             
         }         
         else if(dest1field.getSelectedItem().equals("Peshawar")){
             this.to="Peshawar";
             sl.push(to);
             //to2field.setText("Peshawar");
              
         }
         
         sl.push(SubTotalField1.getText());
         sl.push(dep1.getText());
         
//       amountpaid2field.setText(SubTotalField1.getText());
//       dep2field.setText(dep1.getText());
//       passengers2Field.setText(passengers1Field.getText());
       //from2field.setText("Islamabad");

            //int passengers1 = Integer.parseInt(passengers1Field.getText());
            sl.push(passengers1Field.getText());
            //passengers1Field.setText(passengers1Field.getText());
            
            
             if(dep1field.getSelectedItem().equals("8:30am"))
             {
                this.depTime="8:30am";
                sl.push(depTime);
               // dep2field.setText("8:30am");
            }
             else if(dep1field.getSelectedItem().equals("10:30am"))
             {
                this.depTime="10:30am";
                sl.push(depTime);
                //dep2field.setText("10:30am");
            }
            else if(dep1field.getSelectedItem().equals("8:30pm"))
            {
                this.depTime="8:30pm";
                sl.push(depTime);
               // dep2field.setText("8:30pm");
            }
             
             
             if(SingleButton.isSelected())
             {
                 this.tickettype="Single";
                 sl.push(tickettype);
               // T_type1Field.setText("Single");
                
             }
             else if(ReturnButton.isSelected())
             { 
                this.tickettype="Return";
                 sl.push(tickettype);
               //  T_type1Field.setText("Return");
                
             }
             
             
             if(FirstClassButton.isSelected())
             {
                 this.traveltype="First Class";
                  sl.push(traveltype);
                // class2Field.setText("First Class");
             }
             else if(EconomyButton.isSelected())
             {
                 this.traveltype="Economy";
                 sl.push(traveltype); 
                // class2Field.setText("Economy");
                  
                      
             }
             
             
             date=doj1Field.getDate().toString();
              sl.push(date);
             
           // now pop function will be called
            this.date= sl.pop();
            doj2Field.setText(date);
            
            this.traveltype=sl.pop();
             class2Field.setText(traveltype);
            
            this.tickettype=sl.pop();
            T_type1Field.setText(tickettype);
            
             this.depTime=sl.pop();
             dep2field.setText(depTime);
             
             this.passengernum=sl.pop();
             //passengers1Field.setText(passengernum);
              passengers2Field.setText(passengernum);
              
              
              dep2field.setText(sl.pop());
              amountpaid2field.setText(sl.pop());
               
              this.to=sl.pop();
             to2field.setText(to);
      
            this.from=sl.pop();
            from2field.setText(from);
             
             
             try{
                 
                 FileWriter fw=new FileWriter("Ticketdata.txt");
                 fw.write(this.from+"\t"+to+"\t"+date+"\t"+depTime+"\t"+traveltype+"\t"+passengernum+"\t");
                  updateReserve(from,to,traveldate,depTime,this.passengernum,traveltype);
                 fw.close();
             }
             
             catch(Exception e){
                 System.out.println("cannot open file");
             }
    }//GEN-LAST:event_ReviewActionPerformed

    private void SubmitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SubmitActionPerformed
       
            this.passengernum=passengers1Field.getText();
            int passengers1 = Integer.parseInt(passengers1Field.getText());
            passengers1Field.setText(passengers1Field.getText());

            Tfare= (fare*passengers1);
            Dtax = (tax*passengers1);
            SubTotal = (Dtax + Tfare)*passengers1;
            String Totalfare= String.format("%d",Tfare);
            String DisplayTax = String.format("%d",Dtax);
            String Stotal = String.format("%d",SubTotal);
            total1Field.setText(Totalfare);
            tax1field.setText(DisplayTax);
            SubTotalField1.setText(Stotal);


    }//GEN-LAST:event_SubmitActionPerformed

    private void total1FieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_total1FieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_total1FieldActionPerformed

    private void dest1fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dest1fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dest1fieldActionPerformed

    private void dep1fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dep1fieldActionPerformed

    }//GEN-LAST:event_dep1fieldActionPerformed

    private void SingleButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SingleButtonActionPerformed

    }//GEN-LAST:event_SingleButtonActionPerformed

    private void ReturnButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReturnButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ReturnButtonActionPerformed

    private void FirstClassButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_FirstClassButtonActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_FirstClassButtonActionPerformed

    private void passengers2FieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_passengers2FieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_passengers2FieldActionPerformed

    private void confirmbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_confirmbuttonActionPerformed
        JOptionPane.showMessageDialog(null,"Your Ticket is Reserved");
        Ticket t=new Ticket();
        t.setVisible(true);
    }//GEN-LAST:event_confirmbuttonActionPerformed

    private void exitbuttonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitbuttonActionPerformed
        // TODO add your handling code here:
        Reservation r = new Reservation();
        r.setVisible(true);
    }//GEN-LAST:event_exitbuttonActionPerformed

    private void to2fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_to2fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_to2fieldActionPerformed

    private void doj2FieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doj2FieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_doj2FieldActionPerformed

    private void from2fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_from2fieldActionPerformed

        // TODO add your handling code here:
    }//GEN-LAST:event_from2fieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Reservation.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Reservation().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton EconomyButton;
    private javax.swing.JRadioButton FirstClassButton;
    private javax.swing.JLabel From2;
    private javax.swing.JRadioButton ReturnButton;
    private javax.swing.JButton Review;
    private javax.swing.JRadioButton SingleButton;
    private javax.swing.JTextField SubTotalField1;
    private javax.swing.JButton Submit;
    private javax.swing.JLabel T_type1;
    private javax.swing.JTextField T_type1Field;
    private javax.swing.JLabel To2;
    private javax.swing.JLabel amountpaid2;
    private javax.swing.JTextField amountpaid2field;
    private javax.swing.JLabel class1;
    private javax.swing.JLabel class2;
    private javax.swing.JTextField class2Field;
    private javax.swing.JButton confirmbutton;
    private javax.swing.JLabel dep1;
    private javax.swing.JComboBox<String> dep1field;
    private javax.swing.JLabel dep2;
    private javax.swing.JTextField dep2field;
    private javax.swing.JLabel dest;
    private javax.swing.JComboBox<String> dest1field;
    private javax.swing.JLabel doj1;
    private com.toedter.calendar.JDateChooser doj1Field;
    private javax.swing.JLabel doj2;
    private javax.swing.JTextField doj2Field;
    private javax.swing.JButton exitbutton;
    private javax.swing.JComboBox<String> from1f;
    private javax.swing.JTextField from2field;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel passengers1;
    private javax.swing.JTextField passengers1Field;
    private javax.swing.JLabel passengers2;
    private javax.swing.JTextField passengers2Field;
    private javax.swing.JLabel sub_total1;
    private javax.swing.JLabel tax1;
    private javax.swing.JTextField tax1field;
    private javax.swing.JLabel ticket_type1;
    private javax.swing.JTextField to2field;
    private javax.swing.JLabel total1;
    private javax.swing.JTextField total1Field;
    // End of variables declaration//GEN-END:variables


}
class Node2
{
    int Tfare;
    int Dtax;
    int SubTotal;
    int passengernum;
    String to = null,from, depTime, traveltype, traveldate, date;
    Node2 next;
    String data;
    
    Node2(String data){
    this.data=data;
            next=null;
}
} //end of node class
class StackLinkedlist{
    Node2 head;
    String s;
    StackLinkedlist(){
        head=null;
    }
    
    void push(String data){
    Node2 new_node = new Node2(data);
        if(head==null){
            head=new_node;
        }
        else
        {
            new_node.next=head;
            head=new_node;
        }
        }
    
       String pop(){
        Node2 temp=head;
        
        s=temp.data;// assign data of first node into s 
        
        head=temp.next;
         temp.next=null;
        return s;// returing that data
    }
    } //end of linked list class