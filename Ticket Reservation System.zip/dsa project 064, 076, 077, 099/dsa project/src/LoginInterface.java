
public interface LoginInterface {
    boolean login();
}
