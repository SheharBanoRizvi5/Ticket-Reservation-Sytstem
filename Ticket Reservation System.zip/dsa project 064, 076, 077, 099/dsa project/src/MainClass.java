
public class MainClass {
    
    public static void main(String [] arg){
        
        loginpage l=new loginpage();
        l.setVisible(true);
        l.setLocationRelativeTo(null);
    }
}
